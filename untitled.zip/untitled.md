# untitled



---

## Step 1: Click "Features" link

![Step 1](untitled/step-1.jpg)

## Step 2: Scroll down

![Step 2](untitled/step-2.jpg)

## Step 3: Scroll down

![Step 3](untitled/step-3.jpg)

## Step 4: Scroll to Frequently Asked Questions

![Step 4](untitled/step-4.jpg)

## Step 5: Click "What makes Arkivya different from other ..." button

![Step 5](untitled/step-5.jpg)

