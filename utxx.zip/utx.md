# utx

 

* Created with ArkScribe *

---

## Step 1: New Step x 

![Step 1](utx/step-1.jpg)

## Step 2: Click element 

![Step 2](utx/step-2.jpg)

## Step 3: Click element 

![Step 3](utx/step-3.jpg)

## Step 4: Click element 

![Step 4](utx/step-4.jpg)

## Step 5: Click element 

![Step 5](utx/step-5.jpg)

## Step 6: Click element 

![Step 6](utx/step-6.jpg)

## Step 7: Click element 

![Step 7](utx/step-7.jpg)

## Step 8: Click element 

![Step 8](utx/step-8.jpg)

## Step 9: Click element 

![Step 9](utx/step-9.jpg)

## Step 10: Click element 

![Step 10](utx/step-10.jpg)

## Step 11: Click "See All Integrations" link (integrations) 

![Step 11](utx/step-11.jpg)

## Step 12: Click element 

![Step 12](utx/step-12.jpg)

## Step 13: Click "Webhooks" 

![Step 13](utx/step-13.jpg)

## Step 14: Click "Webhooks" 

![Step 14](utx/step-14.jpg)

## Step 15: Click "Webhooks" 

![Step 15](utx/step-15.jpg)

## Step 16: Click "Webhooks" 

![Step 16](utx/step-16.jpg)

## Step 17: Click "Webhooks" 

![Step 17](utx/step-17.jpg)

## Step 18: Click element 

![Step 18](utx/step-18.jpg)

## Step 19: Click element 

![Step 19](utx/step-19.jpg)

## Step 20: Click element 

![Step 20](utx/step-20.jpg)

## Step 21: Click element 

![Step 21](utx/step-21.jpg)

## Step 22: Click element 

![Step 22](utx/step-22.jpg)

## Step 23: Click element 

![Step 23](utx/step-23.jpg)

## Step 24: Click element 

![Step 24](utx/step-24.jpg)

## Step 25: Click element 

![Step 25](utx/step-25.jpg)

## Step 26: Click "Do I need technical knowledge to connect..." button 

![Step 26](utx/step-26.jpg)

## Step 27: Click "Can I create custom integrations?" button 

![Step 27](utx/step-27.jpg)

## Step 28: Click "Which integrations are available?" button 

![Step 28](utx/step-28.jpg)

## Step 29: Click element 

![Step 29](utx/step-29.jpg)

## Step 30: Click ":" 

![Step 30](utx/step-30.jpg)

## Step 31: Click ":" 

![Step 31](utx/step-31.jpg)

## Step 32: Click element 

![Step 32](utx/step-32.jpg)

## Step 33: Click element 

![Step 33](utx/step-33.jpg)

## Step 34: Click "Extensibility & Options" 

![Step 34](utx/step-34.jpg)

## Step 35: Click element 

![Step 35](utx/step-35.jpg)

## Step 36: Click element 

![Step 36](utx/step-36.jpg)

## Step 37: Click element 

![Step 37](utx/step-37.jpg)

## Step 38: Click element 

![Step 38](utx/step-38.jpg)

## Step 39: Click "Extensibility & Options" 

![Step 39](utx/step-39.jpg)

## Step 40: Click element 

![Step 40](utx/step-40.jpg)

## Step 41: Click element 

![Step 41](utx/step-41.jpg)

## Step 42: Click element 

![Step 42](utx/step-42.jpg)

## Step 43: Click element 

![Step 43](utx/step-43.jpg)

## Step 44: Click element 

![Step 44](utx/step-44.jpg)

## Step 45: Click element 

![Step 45](utx/step-45.jpg)

## Step 46: Click "Contact" link (923114861994) 

![Step 46](utx/step-46.jpg)

## Step 47: Click element 

![Step 47](utx/step-47.jpg)

## Step 48: Click element 

![Step 48](utx/step-48.jpg)

## Step 49: Click "Tools" 

![Step 49](utx/step-49.jpg)

## Step 50: Click element 

![Step 50](utx/step-50.jpg)

## Step 51: Click element 

![Step 51](utx/step-51.jpg)

## Step 52: Click element 

![Step 52](utx/step-52.jpg)

## Step 53: Click element 

![Step 53](utx/step-53.jpg)

## Step 54: Click element 

![Step 54](utx/step-54.jpg)

## Step 55: Click element 

![Step 55](utx/step-55.jpg)

## Step 56: Click element 

![Step 56](utx/step-56.jpg)

## Step 57: Click element 

![Step 57](utx/step-57.jpg)

## Step 58: Click element 

![Step 58](utx/step-58.jpg)

## Step 59: Click element 

![Step 59](utx/step-59.jpg)

## Step 60: Click element 

![Step 60](utx/step-60.jpg)

## Step 61: Click element 

![Step 61](utx/step-61.jpg)

